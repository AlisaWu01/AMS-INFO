    <footer>
      <p>Amsterdaminfo webpage, Copyright &copy; 2017</p>
    </footer>